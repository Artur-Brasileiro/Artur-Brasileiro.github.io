# Eletrônica

> **`fiacao.html`**, nesta pasta, é o diagrama interativo: abra no navegador, toque numa
> cor e só aquele fio fica aceso. Tem também a tabela ponto a ponto, a calculadora do
> Vref (A4988 ou DRV8825) e a ordem segura para ligar. É a mesma seção da página do
> projeto no portfólio.

Arduino UNO + driver de passo vermelho (chip HR4988, placa HW-134A, compatível com
A4988) numa protoboard, NEMA 17 17HS4401S, encoder LPD3806-1000BM e fonte de 12 V 5 A.
A CNC shield não foi usada.

## Energia

```
fonte 12 V ──► divisor Y ──┬──► jack P4 do Arduino   (Arduino e lógica)
                           └──► P4 fêmea com borne ──► faixa de 12 V da protoboard ──► VMOT do driver
Arduino 5 V ──► faixa de 5 V da protoboard ──► VDD do driver e encoder
```

Uma fonte só alimenta tudo; o computador não é necessário para rodar.

## Pinos

| sinal | pino do Arduino | por quê |
|---|---|---|
| encoder A | D2 | os únicos pinos do UNO com interrupção externa são D2 e D3 |
| encoder B | D3 | |
| STEP | D9 | o firmware final gera os passos pelo Timer1 e pulsa direto na porta (PB1) |
| DIR | D8 | |
| EN | D10 | LOW = motor ligado |

No driver: **MS2 no 5 V** (1/4 de passo), **RST ligado no SLP** (jumper), motor nas
duas bobinas (1A/1B e 2A/2B).

Encoder: vermelho no 5 V, preto no GND, verde (A) no D2, branco (B) no D3. As cores
variam de fabricante para fabricante; o sentido da contagem se ajusta no código
(`SINAL_ENCODER`).

## Antes de ligar o motor

1. **Capacitor de 100 µF / 25 V** entre +12 V e GND, perto do VMOT, com a perna − no GND.
   Sem ele, o pico de tensão do motor pode queimar o driver no primeiro liga.
2. **Corrente do driver (Vref):** para 1,0 A num A4988 com resistor R100,
   `Vref = corrente × 8 × Rs = 0,80 V`, medido entre o potenciômetro e o GND.
   O motor aguenta 1,5 A, mas 1,0 A esquenta menos e já sobra força.
3. Ajuste o Vref **sem** o motor ligado. Desligue a fonte, ligue o motor, ligue a fonte.
4. **Nunca** encaixe ou tire os fios do motor com a fonte ligada: é isso que queima o driver.

## Problemas que apareceram

| sintoma | causa | solução |
|---|---|---|
| "Acesso negado" na COM7 ao enviar o código | o Cura (fatiador) estava aberto e segurando a porta serial | fechar o Cura e enviar de novo |
| dúvida se tirar o USB queima algo | — | não queima: com a fonte ligada o Arduino continua alimentado pelo jack |

## Montagem na tábua

A eletrônica fica numa bandeja impressa (`bandeja_eletronica`): Arduino e protoboard à
vista, o P4 com borne escondido numa capa (`capa_p4`) que desliza num trilho e trava com
um pino (`pino_trava`). As configurações de impressão estão em
`01_mecanica/configuracao_impressao.md`.
