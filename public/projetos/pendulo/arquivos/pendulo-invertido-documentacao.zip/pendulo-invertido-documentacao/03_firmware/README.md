# Firmware (Arduino UNO)

Os códigos estão na ordem em que foram usados. A ideia foi testar uma coisa de cada vez:
primeiro o sensor, depois o motor, depois medir a haste, e só então o controle. Assim,
quando algo não funciona, só existe um suspeito.

## 1. Testes (`1_testes/`)

| sketch | o que testa | resultado |
|---|---|---|
| `teste_encoder` | lê o encoder e mostra o ângulo no Monitor Serial. Uma volta tem de dar 4000 contagens | funcionou de primeira |
| `teste_motor` | anda o carro ±50 / ±150 mm com 4 velocidades, partindo do meio do trilho | sentido certo, 50 mm exatos, até 400 mm/s sem perder passo |
| `teste_motor_v2` | o mesmo, mas partindo encostado no batente do motor, com limites de 20 mm de cada batente | é o esquema de partida usado no controle |
| `medir_pendulo` | mede o período e o atrito da haste pelo encoder | 1,121 s; 24 balanços até cair à metade |

Todos abrem o Monitor Serial em **115200**.

## 2. Final (`2_final/pendulo_controle/`)

`pendulo_controle.ino` é o código que roda no aparelho. Ligou a fonte, ele:

1. confere se o motor tem 12 V (um empurrãozinho de 6 mm; se a haste não se mexe, espera a fonte);
2. sai do batente já balançando a haste (subida por energia);
3. pega no topo e equilibra a 200 Hz (LQR);
4. se a haste cair, volta a subir no mesmo ciclo.

O `GUIA_CONTROLE.md`, ao lado, explica como ligar, o que cada modo faz, os ajustes e o
que fazer se algo der errado.

### Como ele está organizado

| parte | o que faz |
|---|---|
| gerador de passos (Timer1) | uma interrupção dá cada passo no tempo certo; o `loop()` só diz a velocidade. A trava dos 20 mm mora aqui, então nem um bug no controle passa dela |
| encoder (D2 e D3) | decodificação em quadratura por tabela, nas duas bordas dos dois canais: 4000 contagens por volta |
| `loop()` a 200 Hz | lê ângulo e posição, decide a aceleração e entrega uma velocidade ao gerador |
| subida | vai e vem que inverte quando a haste passa por baixo; enfraquece perto da energia do topo |
| equilíbrio | `a = −(K_X·x + K_V·v + K_T·θ + K_W·ω)`, com um integrador lento que corrige um zero levemente torto |
| limites | aceleração ≤ 8 m/s², velocidade ≤ 0,40 m/s, e freia antes de ±165 mm do centro |

## 3. Histórico (`3_historico/`)

`pendulo_controle_v1_bancada` foi a primeira versão do controle, para bancada: comandos
pelo Monitor Serial (`b` para levantar a haste com a mão e soltar quando o controle
pegasse, `s` para a subida automática, `x` para parar). Serviu para testar o equilíbrio
sozinho antes da subida. **Não é para usar**: a versão final substituiu ela.
