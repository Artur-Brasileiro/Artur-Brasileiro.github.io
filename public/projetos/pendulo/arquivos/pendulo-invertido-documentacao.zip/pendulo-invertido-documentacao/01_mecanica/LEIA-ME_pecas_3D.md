# Pêndulo invertido — trilho MGN15H

Peças projetadas para: trilho MGN15H 500 mm + bloco MGN15H, NEMA 17 (17HS4401S),
encoder LPD3806-1000BM-G5-24C e correia GT2 de 6 mm.

## Peças para imprimir (pasta `stl/` do pacote, já na orientação de impressão)

| Arquivo | Qtd | Observação |
|---|---|---|
| carro_encoder.stl | 1 | base no bico; PETG ou PLA, 4 paredes, 40 % de preenchimento |
| garra_correia.stl | 1 | já está de cabeça para baixo (dentinhos para cima) |
| cubo_pendulo.stl | 1 | face da frente na mesa; 100 % de preenchimento recomendado |
| suporte_motor.stl | 1 | pé na mesa |
| polia_motor_gt2_30d.stl | 1 | camada 0,12 mm; se os dentes saírem ruins, use uma GT2 metálica (ver abaixo) |
| esticador_base.stl | 1 | piso na mesa |
| esticador_carro.stl | 1 | base na mesa |
| rolo_esticador.stl | 1 | furo de Ø16,1 para 2× 625ZZ prensados |
| batente_trilho_x2.stl | 2 | TPU fica melhor, PLA funciona |
| TESTE_encaixe_encoder.stl | 1 | opcional: só a flange, para testar os furos de rosca |

Nada precisa de suporte. Tudo cabe na mesa da Ender-3 V3 SE.

## Medidas do encoder usadas no modelo

Conferidas com paquímetro: corpo Ø38 × 35 mm, ressalto Ø20 × 5 mm, eixo Ø6 com
15 mm além do ressalto (55 mm no total). O berço tem Ø38,6, o furo do ressalto Ø20,6 e o
furo do cubo vai 15,6 mm de fundo. Os rasgos em arco da flange aceitam furos de rosca num
círculo de Ø27,6 a Ø30,4 (ficha da série: Ø28 e Ø30).

## Parafusos e rolamentos

- 4× M3×8 — carro no bloco MGN15H (o bloco tem rosca M3 com 4 mm)
- 3× M3×8 + arruela — encoder na flange (se a rosca do encoder for funda, M3×10)
- 4× M3×12 + 4 porcas — garra da correia (porcas encaixam por baixo do carro)
- 1× M3×10 + porca — cubo travando no eixo do encoder (no chato do "D")
- 1× M3×8 + porca — cubo travando a haste
- 4× M3×10 — motor no suporte
- 1× M3×6 sem cabeça (ou M3×8) + porca — polia no eixo do motor
- 2× rolamento 625ZZ, 1× M5×30 + porca + 2 arruelas — rolo do esticador
- 1× M5×30 + porca + arruela — parafuso tensor (porca M5 entra por cima no carrinho)
- 2× M3×25 — trocam o parafuso do 1º e do último furo do trilho e prendem os batentes
- ~9× parafuso para madeira 4 mm cabeça chata — fixação na base
- 1× haste de inox Ø6 mm × 500 mm para o pêndulo

## Medidas de montagem

Tudo é referenciado ao **eixo do trilho**:

- A aba fina (3 mm) do suporte do motor e da base do esticador **encosta na lateral
  traseira do trilho**. Isso deixa o plano da correia a 32 mm do eixo do trilho, alinhado
  com a garra do carro, sem precisar medir.
- Eixo do motor: 30 mm antes do início do trilho. Eixo do rolo: 30 mm depois do fim.
- Correia (ramo de baixo) passa a 22 mm da base — exatamente no topo da garra.
- Eixo do encoder: 44 mm acima da base. Pêndulo gira 40,5 mm à frente do eixo do trilho:
  o eixo do trilho deve ficar a no máximo ~30 mm da borda da mesa/base para a haste passar
  livre por baixo.
- Curso do carro entre os batentes: ~410 mm no modelo (412 mm medidos).

## Ordem de montagem

1. Prenda o trilho na base, perto da borda da frente.
2. Parafuse o carro no bloco (4× M3×8) **antes** de colocar o encoder — os parafusos
   ficam embaixo dele.
3. Encaixe o ressalto Ø20 do encoder no furo da flange, gire até o cabo apontar para
   cima e aperte os 3× M3 nos rasgos em arco (eles aceitam os furos de Ø28 e Ø30 em
   qualquer posição).
4. Monte motor + polia no suporte; monte o rolo (2× 625ZZ) no carrinho do esticador.
   A base do esticador não tem porca escondida: pode parafusá-la na tábua primeiro.
   O carrinho entra deslizando pela ponta aberta da base (as abas em 45° das paredes
   o seguram para baixo) e é puxado pelo M5, que passa na parede e rosca na porca M5
   encaixada por cima do carrinho.
5. Encoste as abas na lateral do trilho e parafuse os dois suportes na base.
6. Passe a correia, prenda as duas pontas embaixo da garra (dentes da correia para cima,
   encaixando nos dentinhos da garra) e tensione girando o M5 da ponta. A própria
   tensão da correia segura a regulagem.
7. Cubo no eixo do encoder, haste no cubo.

## Polia metálica em vez da impressa

Uma GT2 metálica (20T, furo 5 mm, correia 6 mm) também serve: mude `MOTOR_TEETH = 20`
em `pendulo.py` e rode o `export.py`; a altura do motor é recalculada para a correia
continuar paralela ao trilho. No firmware, `PASSOS_POR_MM` passa a ser `800.0 / 40.0`.
