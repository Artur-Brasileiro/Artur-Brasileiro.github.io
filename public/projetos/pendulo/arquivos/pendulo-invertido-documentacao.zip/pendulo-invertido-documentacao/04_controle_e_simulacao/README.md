# Controle e simulação

Antes de ligar o motor com a haste, o controle foi testado num "pêndulo de mentira":
uma simulação com as medidas da haste de verdade e o mesmo código do Arduino, linha por
linha. Se ele não equilibra no computador, não vai equilibrar na bancada, e cada
tentativa errada na bancada é um carro batendo no fim do trilho.

## Arquivos

| arquivo | o que faz |
|---|---|
| `calcular_ganhos.py` | calcula os 4 ganhos do equilíbrio (LQR) a partir das medidas da haste. Sai exatamente o que está no firmware |
| `sim_autonomo.py` | espelho do firmware final: liga no batente do motor, sobe, equilibra; testa atrito, inércia e tapas |
| `saida_da_simulacao.txt` | o que o `sim_autonomo.py` imprime |

```bash
pip install numpy scipy
python calcular_ganhos.py
python sim_autonomo.py
```

## O modelo, em uma frase

O carro é levado por motor de passo, então ele **vai exatamente para onde o código manda**:
para a física, a entrada é a aceleração do carro, não uma força. Isso simplifica tudo:
não precisa saber a massa do carro nem o atrito do trilho, só a haste.

```
J·θ'' = m·g·d·sen θ − m·d·a·cos θ − atrito do encoder
```

| medida | valor | de onde veio |
|---|---|---|
| massa da haste `m` | 110 g | balança de cozinha |
| eixo ao centro de massa `d` | 215 mm | haste de 500 mm com o eixo a 35 mm da ponta |
| inércia `J` | 0,007388 kg·m² | calculada e conferida pelo período medido (1,121 s) |
| atrito seco do encoder | perde ~0,6° de amplitude por balanço | `medir_pendulo` (24 balanços até cair à metade) |

## O que a simulação imita do aparelho real

- **Encoder de 4000 contagens:** o ângulo chega "em degraus" de 0,09°, como no Arduino.
- **Velocidade angular por diferença** entre leituras, como o firmware calcula.
- **Posição pela contagem de passos:** o carro sabe onde está porque contou os passos.
- **Controle a 200 Hz** (um ciclo a cada 5 ms), com os mesmos limites: 8 m/s², 0,40 m/s, ±165 mm.
- **A trava do gerador de passos:** nunca a menos de 20 mm de um batente.

## Resultados (os que estão no guia do controle)

Com o atrito medido, ruído, atraso de 5 ms e o modelo variando ±2 %:

| teste | resultado |
|---|---|
| partindo do batente do motor | ficou em pé em **60 de 60**, em **4,5 s** típico e 10 s no pior caso |
| derrubando com tapas | reergueu em **38 de 38** quedas, em **1,9 s** típico e 6 s no pior caso |
| distância mínima de um batente | **43 mm**, nunca menos |

Os testes de Monte Carlo (os 60 e os 38) foram feitos com scripts de apoio em volta do
`sim_autonomo.py`; o caso nominal e as variações de atrito e inércia estão em
`saida_da_simulacao.txt`.
