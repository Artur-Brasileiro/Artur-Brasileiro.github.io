# Como montar a CNC Plotter

Uma plotter de 2 eixos feita com peças impressas em 3D, barras de aço, Arduino e GRBL, pensada para desenhar **quadros grandes e alongados** (área útil de **810 × 390 mm**, proporção perto de 2:1). Este guia junta tudo o que foi aprendido construindo a máquina: o que comprar, como montar, como ligar, como configurar e o que fazer quando algo dá errado.

Os dados vêm marcados pela origem, como no caderno de bordo do projeto:

- **[medido]**: medido na bancada.
- **[modelo]**: tirado do modelo 3D (FreeCAD).
- **[calc.]**: estimativa calculada.
- **[decisão]**: escolha de projeto, com o motivo.

---

## 1. Visão geral

A máquina é uma **ponte (gantry)** que anda sobre duas barras compridas, com um carro que anda sobre a ponte levando a caneta.

- **Eixo X (longo):** a ponte inteira corre sobre **2 barras de aço de 12 mm × 1000 mm**, presas na mesa.
- **Eixo Y (curto):** o carro da caneta corre sobre **2 barras de 6 mm × 500 mm**, presas na ponte.
- **Caneta:** sobe e desce com um **servo**, comandado pelo próprio GRBL (`M5` sobe, `M3 S220` desce).
- **Os dois motores andam junto com a ponte**, montados na Base Principal. O eixo X usa **tração em ômega**: a correia fica parada e o motor "escala" por ela.

[[LAYOUT]]

**Convenção de lados usada no guia** (operador em pé de frente para a máquina):

- **Frente:** lado do Apoio Secundário (barra de 12 mm mais alta, a 80 mm da mesa).
- **Fundo:** lado da Base Principal e dos motores (barra de 12 mm mais baixa, a 51,4 mm).
- **X+ = para a direita. Y+ = para longe do operador** (em direção à Base Principal).
- **Origem do papel (0,0):** canto da frente à esquerda. **Home:** ponte toda à direita e carro no fundo.

| Especificação | Valor | Origem |
|---|---|---|
| Área útil | **810 × 390 mm** | [medido] |
| Resolução | 0,0125 mm por micropasso (1/16, 80 passos/mm) | [calc.] |
| Velocidade de desenho recomendada | F500 para precisão máxima; até F1000–1500 sem perda visível | [medido] |
| Deslocamento com caneta levantada | até 200 mm/s (`$110` = 12000 mm/min) | [medido] |
| Aceleração | 800 mm/s² | [medido] |
| Massa móvel do eixo X | ≈ 1,2 kg (com os 2 motores) | [calc.] |
| Massa móvel do eixo Y | ≈ 110 g | [calc.] |
| Mesa | tampo de pinus 700 × 1200 × 18 mm | [medido] |
| Controle | Arduino Uno + CNC Shield V3 + GRBL 1.1h (fork com servo) | — |
| Software no PC | LaserGRBL (Windows) | — |

---

## 2. Lista de materiais

### 2.1 Mecânica

| Item | Qtd. | Observação |
|---|---|---|
| Barra de aço Ø12 × 1000 mm | 2 | eixo X |
| Barra de aço Ø6 × 500 mm | 2 | eixo Y (na ponte) |
| Haste de aço Ø6 × 73,4 mm | 2 | guia vertical do Pen Holder |
| Rolamento linear **LM12UU** (Ø12 × Ø21 × 30 mm) | 3 | 2 no Apoio Base + 1 no Apoio Secundário |
| Rolamento linear **LM6UU** | 8 | 4 no carro (2 por túnel) + 4 no Pen Holder (2 por haste) |
| Polia **GT2 20 dentes**, furo 5 mm | 2 | uma em cada motor |
| Polia louca GT2 | 3 | 2 para o ômega do eixo X + 1 dentada no Apoio Secundário (retorno do Y) |
| Correia **GT2 6 mm** | ~3 m | ≈ 1,15 m no Y + ≈ 1,1 m no X **[calc.]**; compre com sobra |
| Tampo de pinus 700 × 1200 × 18 mm | 1 | a "mesa" da máquina |
| Mola pequena | 1 | pressão da caneta no Pen Holder |
| Peso de 150–200 g | 1 | preso no Apoio Secundário (ver 4.4) |
| Parafusos M4 de cabeça chata para madeira | ~14 | suportes e base da eletrônica (4 × 16 mm na base) |
| Parafusos M3 + porcas | ~25 | suportes (4 por suporte), Pen Holder (2 com porcas presas) |
| Parafusos M3 × 30 + porca | 2 | presilhas da correia do Y |
| Parafusos M3 × 6 autoatarraxantes | 4 | Arduino na base impressa |

### 2.2 Eletrônica

| Item | Qtd. | Observação |
|---|---|---|
| Arduino Uno | 1 | |
| CNC Shield V3 | 1 | |
| Driver A4988 / HR4988 | 2 | +1 reserva; slots X e Y |
| Jumpers de micropasso | 6 | 3 embaixo de cada driver usado (1/16) |
| Motor de passo NEMA 17 **US-17HS4401S** | 2 | 1,7 A/fase, ~1,5 Ω, 200 passos/volta, ~280 g |
| Fonte chaveada **12 V / 5 A** com plugue P4 | 1 | |
| Divisor Y P4 (1 fêmea → 2 machos) | 1 | |
| Jack P4 fêmea com borne | 2 | um para o shield, outro para o step-down |
| Módulo step-down 12 V → 5 V (≈ 18 × 12 mm) | 1 | alimenta **só** o servo |
| Servo **MG90S** (ou SG90) | 1 | levanta a caneta |
| Microswitch com rolete (COM / NO / NC) | 2 | fins de curso X e Y |
| Cabo USB A-B | 1 | PC ↔ Arduino |
| Fios: cabos de motor de 4 vias, par trançado para os fins de curso, jumpers | — | |

### 2.3 Peças impressas

| Peça | Qtd. | Material | Função |
|---|---|---|---|
| Suporte alto (base em L + abraçadeira, 88,7 mm) | 2 | PLA | segura a barra de 12 mm da **frente** |
| Suporte baixo (base em L + abraçadeira, 60 mm) | 2 | PLA | segura a barra de 12 mm do **fundo** e as pontas da correia do X |
| Base Principal | 1 | PLA | placa dos motores, em cima do Apoio Base |
| Apoio Base | 1 | PLA | 2 × LM12UU na barra do fundo |
| Apoio Secundário | 1 | PLA | 1 × LM12UU na barra da frente + polia louca do Y |
| Carro Principal **v3** | 1 | **PETG** | leva a caneta; 4 × LM6UU |
| Pen Holder **v3** | 1 | **PETG** | segura a caneta; 4 × LM6UU |
| Presilha da correia GT2 | 2 | PLA | prende as pontas da correia do Y no carro |
| Base_CNC_Shield | 1 | PLA | Arduino + shield rente à mesa (4 mm) |

O modelo completo (assembly) foi feito no **FreeCAD**. A base do shield foi gerada em CadQuery e o script está em `modelos-3d/base-cnc-shield/base.py`.

---

## 3. Antes de começar: três ideias que explicam a máquina

**1. Guiar de um lado, apoiar do outro.** O projeto previa 2 rolamentos no Apoio Secundário, mas com 4 rolamentos firmes em 2 barras o sistema fica **hiperestático**: qualquer falta de paralelismo faz os dois lados "brigarem", e isso aparece como trepidação (*stick-slip*, trava e solta). Com **2 rolamentos no fundo (que guiam) e 1 na frente (que só apoia)**, a máquina tolera pequenos desalinhamentos. É como uma gaveta: a boa tem um trilho que guia e outro que só segura o peso.

**2. O motor escala a correia.** No eixo X, a correia fica presa nas duas pontas e não se move. Ela passa por baixo de duas polias loucas e dá a volta na polia do motor. Quando o motor gira, ele "sobe" pela correia, levando a ponte junto, como alguém puxando o próprio corpo ao longo de uma corda esticada.

**3. A caneta cai por gravidade (com ajuda de uma mola).** O servo não empurra a caneta para baixo: ele só a **levanta**. Para descer, o servo sai do caminho e o Pen Holder desce pelo próprio peso e pela mola. Assim, a caneta acompanha pequenas ondulações da mesa ou a flecha das barras sem perder o contato com o papel.

---

## 4. Montagem mecânica

### 4.1 Imprimir as peças

- Estrutura em **PLA** (Creality Ender). Carro e Pen Holder v3 em **PETG** (impressos numa Snapmaker).
- Dica geral: imprima as abraçadeiras com o eixo do furo de 12,2 mm na vertical, para o furo sair redondo.
- No carro v3, os furos dos LM6UU têm **nervuras de pressão** (3 por furo, inscrito Ø11,9): o rolamento entra justo e fica sem folga, sem depender da tolerância da impressora.

### 4.2 Mesa, suportes e barras de 12 mm

1. Parafuse os **2 suportes baixos** (fundo) e os **2 suportes altos** (frente) no tampo com parafusos M4 de cabeça chata.
2. A distância entre os eixos das barras é **516 mm** **[modelo]**. Meça nas duas pontas: as barras precisam ficar paralelas, senão a ponte trava em algum trecho do curso.
3. Cada suporte tem 2 peças (base em L + abraçadeira), unidas por 4 parafusos M3. Encaixe a barra e aperte as abraçadeiras por igual.
4. Alturas finais **[modelo]**: barra do fundo a **51,4 mm** da mesa, barra da frente a **80 mm**.
   - Essa diferença (28,6 mm) é proposital **[decisão]**: o Apoio Base, com 2 rolamentos, fica embaixo da Base Principal, e mesmo assim as barras de 6 mm da ponte ficam niveladas a 80 mm.
5. O vão livre entre as abraçadeiras fica em **920 mm**. Desses, a ponte ocupa ~100 mm, e sobram ~820 mm de curso.

### 4.3 Ponte (eixo Y)

1. Coloque os **2 LM12UU no Apoio Base**, a **66 mm** de centro a centro, e passe pela barra do fundo.
2. Coloque **1 LM12UU no Apoio Secundário**, centralizado, e passe pela barra da frente.
3. Prenda as **2 barras de 6 mm × 500 mm** entre o Apoio Base/Base Principal e o Apoio Secundário: **64 mm** entre elas, **450 mm** de vão livre.
4. Empurre a ponte com a mão de ponta a ponta. Ela deve correr leve e por igual. Se travar num trecho, o problema é paralelismo das barras de 12 mm.

> **Por que as barras de 6 mm ajudam:** elas são finas o bastante para flexionar um pouco. 1 mm de desalinhamento entre as barras de 12 mm gera só ~3 N de força lateral **[calc.]**, que as barras de 6 mm absorvem como molas.

### 4.4 Peso no Apoio Secundário

O Apoio Secundário é leve (~15–20% do peso da ponte) e é puxado de lado pelas barras de 6 mm. Com pouca carga, a folga do rolamento "bate" de um lado para o outro e a ponte trepida. **Um peso de 150–200 g preso nele pré-carrega o rolamento** e a trepidação some **[medido]**. O teste com peso também deixou as curvas rápidas mais limpas (ver 9.2).

### 4.5 Motores e correia do eixo X (ômega)

1. Os dois motores ficam na **Base Principal**, na linha do meio entre as barras de 6 mm, a **56 mm** um do outro.
2. **Motor do X** (eixo longo): em cima da placa, com o eixo **para baixo**, polia GT2 20T.
3. Prenda uma ponta da correia num suporte do fundo, passe por baixo da **primeira polia louca**, dê a volta na **polia do motor**, passe pela **segunda polia louca** e prenda a outra ponta no outro suporte do fundo. A tensão é ajustada pelo **esticador por parafuso** num dos suportes.
4. Estique até a correia ficar firme, sem "barriga", mas sem forçar (tensão de violão afinado grave, não de corda de arco).

### 4.6 Motor e correia do eixo Y

1. **Motor do Y** (eixo curto): preso **por baixo** da Base Principal, com o eixo **para cima**. A polia passa pelo furo de Ø25.
2. A correia fecha um laço entre a polia do motor e a **polia louca dentada do Apoio Secundário** (a 89 mm de altura, a 529,5 mm de distância entre os centros **[modelo]**).
3. As duas pontas da correia vão presas no carro pelas **presilhas GT2** (ver 4.8).

### 4.7 Carro e Pen Holder (v3)

1. Coloque **2 LM6UU em cada túnel** do Carro Principal (4 no total). O anel central serve de batente.
2. Passe o carro pelas barras de 6 mm.
3. No **Pen Holder**, coloque **2 LM6UU em cada furo** (4 no total) e passe pelas **2 hastes verticais de Ø6 × 73,4 mm** do carro. Com 40 mm de guia por haste (antes eram 19 mm), a caneta inclina a metade.
4. Coloque a **mola** no Pen Holder.
5. Prenda o **servo** no carro (vão de 23,5 mm, parafusos do próprio servo nos furos de Ø1,8 mm). O braço do servo empurra o pino do Pen Holder para cima.
6. **Caneta:** passe pelo rasgo aberto de 16 mm do carro e pelo furo do Pen Holder. Os **2 parafusos M3** (a 28 mm um do outro, em porcas presas) empurram a caneta contra um **canal em V de 90°**, que centraliza qualquer diâmetro de 3 a 12 mm.

> **Por que o rasgo aberto (v3):** na v2, o furo do "C" do carro tinha Ø12,2 e o do Pen Holder Ø12. Os parafusos empurravam a caneta para fora do centro e ela raspava no carro, travando. Com o rasgo de 16 mm, sobra pelo menos ~2,3 mm de folga para qualquer caneta **[modelo]**.

### 4.8 Presilhas da correia do Y

Cada presilha tem um pino de Ø8,5 mm, uma aba e uma **fenda de entrada de 2,5 mm**.

1. Passe a correia pela fenda, dê a volta no pino **com os dentes virados para o pino** e volte pela mesma fenda.
2. A correia trava dente com dente: as duas pernas juntas medem ~2,0 mm, e para escorregar os dentes teriam que "pular" ~2,8 mm **[calc.]**.
3. Prenda cada presilha com **M3 × 30 + porca** no rasgo de 23,2 × 3,2 mm do carro. O parafuso corre no rasgo e dá **~8 mm de ajuste de tensão**.

### 4.9 Fins de curso

- **X:** microswitch com rolete acionado quando a **ponte chega toda à direita** (X+).
- **Y:** embaixo da Base Principal, entre as barras de 6 mm, acionado pelo **"dedo"** do carro (5 × 14 mm, descendo 7 mm) quando ele chega ao fundo (Y+).
- Ligação: **COM** no GND e **NO** no sinal (detalhes no [esquema de ligações](../esquemas/ligacoes.html)).

### 4.10 Eletrônica na mesa

- Imprima a **Base_CNC_Shield** (101,6 × 62,3 × 4 mm, ~5 g) e prenda na mesa com 2 parafusos M4 × 16 de cabeça chata.
  - Pinus perto da borda racha fácil: faça um furo-guia de ~2,5 mm antes.
- Posição **[decisão]**: no **meio do comprimento da mesa**, na **borda do fundo** (lado dos motores). Como os motores andam com a ponte, ficar no meio do curso reduz a sobra de fio necessária para ~metade do curso (~410 mm), e não o curso inteiro.
- Prenda o Arduino com 4 parafusos **M3 × 6 autoatarraxantes**. O quadro da base fica todo fora do contorno da placa, então nenhum pino soldado encosta no plástico.
- **Atenção à altura:** quem decide se cabe embaixo do Apoio Base é a pilha de eletrônica. Uno + shield + drivers com dissipador dá ~27–30 mm, e os plugues dos motores podem passar de ~33 mm. Passe a ponte devagar com a mão por cima antes de parafusar.
- Cabos que acompanham a ponte: deixe um caminho controlado (uma esteira porta-cabos impressa é a solução prevista) e prenda o fio do servo ao longo da ponte para não enroscar.

---

## 5. Ligações elétricas

O esquema completo e interativo está em **[esquemas/ligacoes.html](../esquemas/ligacoes.html)**. O resumo:

1. **Fonte 12 V / 5 A → divisor Y P4 → 2 jacks P4 fêmea com borne.**
   - **Jack A → borne do CNC Shield** (motores).
   - **Jack B → step-down 12 → 5 V → servo.**
   - Os dois saem da mesma fonte, então o **GND fica em comum**.
2. **Motores:** eixo longo na saída **X**, eixo curto na saída **Y**. Cada par de fios com ~1,5 Ω é uma bobina (um par em 1A/1B, o outro em 2A/2B).
3. **Fins de curso** no conector END STOPS: **X+** (sinal D9) e **Y+** (sinal D10), pino branco = sinal, pino preto = GND.
4. **Servo:** sinal no **Z+ branco (D11)**, 5 V e GND no step-down. **Nunca ligue fim de curso em Z−/Z+.**
5. **Micropasso:** 3 jumpers (M0, M1, M2) embaixo dos drivers X e Y = **1/16**.
6. **Corrente dos motores:** `I = Vref / (8 · Rs)`. Com Vref ≈ 0,60 V **[medido]** e Rs = 0,05 Ω, dá ≈ 1,5 A, abaixo dos 1,7 A do motor. Depois de vários minutos rodando, o dissipador fica só morno **[medido]**.

> **Por que o servo tem fonte própria:** ligado no 5 V do Arduino (que vem do USB), o pico de corrente do servo derrubava a tensão e **resetava o Arduino** no meio do desenho. O LaserGRBL acusava *UnexpectedReset* logo depois do primeiro `M3`, e a máquina perdia a origem. Com o fio de 5 V do servo desligado, o desenho ia até o fim. É como ligar o chuveiro e a luz da casa piscar.

**Regras de segurança:**

- Confira a polaridade da fonte com multímetro (os dois fios dela podem ser pretos).
- Ajuste o step-down para **5,0 V** antes de ligar o servo.
- Alinhe o pino **EN** de cada driver com o EN do shield. Invertido, o driver queima.
- **Desligar:** primeiro os 12 V, depois o USB.
- **Nunca** conecte ou desconecte um motor com o sistema ligado.

---

## 6. Firmware (GRBL com servo)

### 6.1 Gravar

1. Baixe o fork **vankesteren/grbl-servo** (GRBL 1.1h com controle de servo pelo PWM do spindle, no pino D11).
2. Copie a pasta `grbl` para `Documentos/Arduino/libraries`.
3. Na Arduino IDE: **Arquivo → Exemplos → grbl → grblUpload**, placa Arduino Uno, e grave.
4. O aviso *"Low memory available"* é normal no GRBL (92% de flash, 79% de RAM).
5. Esse fork já vem com o homing só em X e Y (sem Z), então não precisa recompilar nada.

### 6.2 Configurar

Envie os comandos do arquivo **`firmware/configuracao_grbl.txt`** pelo console do LaserGRBL. Os mais importantes:

| Parâmetro | Valor | Por quê |
|---|---|---|
| `$32` | **0** | modo não-laser: **obrigatório** para o servo |
| `$30` | **255** | escala do PWM. Com o padrão 1000, `S255` dava só 25% e o servo não se mexia |
| `$100` / `$101` | **80** | 1/16 de micropasso × 200 passos ÷ 40 mm por volta |
| `$110` / `$111` | 12000 | 200 mm/s nos deslocamentos |
| `$120` / `$121` | 800 | reduzir para 400 não melhorou as curvas **[medido]** |
| `$130` / `$131` | **810 / 390** | curso útil medido (no Y sobram ~2 mm até o fim mecânico) |
| `$3` | **3** | inverte X e Y; confira na sua montagem (ver 7.1) |
| `$5` | 0 | fins de curso em NO (1 se usar NC) |
| `$20` / `$21` | 1 / 0 | limite por software ligado; físico desligado |
| `$22` / `$23` | 1 / 0 | homing ligado, no sentido + |
| `$24` / `$25` | 200 / **4000** | aproximação / busca. Acima de ~5000 a ponte de 1,2 kg bate forte na chave |
| `$26` / `$27` | 250 / 3 | debounce (ms) / recuo depois de tocar a chave (mm) |

---

## 7. Primeiros movimentos e calibração

### 7.1 Sentido dos eixos

1. Ligue, conecte o LaserGRBL (porta COM, **115200**) e desbloqueie com `$X`.
2. Envie `G91 G0 X10`: a ponte deve ir para a **direita**. Envie `G91 G0 Y10`: o carro deve ir para **longe de você**. Depois, `G90`.
3. Se algum eixo for ao contrário, ajuste o `$3` (1 = inverte X, 2 = inverte Y, 3 = os dois) ou gire o plugue do motor 180° **com tudo desligado**.
   - Histórico: começou em `$3=2`; depois que o plugue do motor X foi reconectado invertido, passou para `$3=3`. **Marque a orientação dos plugues.**

### 7.2 Escala

1. Rode **`gcode/testes/teste_escala.gcode`**: réguas de 150 mm (X) e 100 mm (Y).
2. Meça. Se der diferente: `$100 novo = $100 atual × (comandado ÷ medido)`.
3. Resultado na máquina: 150 mm em X parou **exatamente** na marca; 20 mm em Y deram 20 mm exatos no paquímetro **[medido]**.

> **Cuidado com medição curta:** um primeiro teste de ±10 mm indicou só 7 mm. Era folga/erro de leitura num deslocamento pequeno, não erro de escala. Meça sempre distâncias longas e num sentido só.

### 7.3 Homing e origem

1. Antes do primeiro `$H`, confira que X+ e Y+ apontam para as chaves (7.1).
2. Com a ponte e o carro no meio do curso, envie `$H` (botão da casinha). Os dois eixos vão até as chaves, recuam, encostam devagar e recuam de novo.
3. Rode **uma vez** `firmware/configurar_origem.gcode`:

```
G92.1
G10 L2 P1 X-810 Y-390
```

Isso grava na EEPROM que o (0,0) do papel fica no **canto da frente à esquerda**. Depois de cada `$H`, o (0,0) volta exatamente ao mesmo ponto físico, e as coordenadas do desenho vão de 0 a 810 (X) e de 0 a 390 (Y), todas positivas, como no Inkscape.

> **Como a máquina "sabe" o tamanho:** ela não tem sensor do lado oposto. No `$H` ela encosta na chave e chama aquele ponto de zero; depois só conta passos (80 por mm). É como andar numa garagem escura contando os passos a partir da parede. Por isso, se você empurrar a ponte com a mão ou a máquina perder passos, precisa fazer `$H` de novo.

**Dica:** desenhe um gabarito na madeira da mesa com a própria máquina (limite da área útil, réguas a cada 10 mm, cantos de A4 e A3). Fica muito mais fácil posicionar o papel.

### 7.4 Caneta

| Estado | Comando | O que acontece |
|---|---|---|
| **Caneta em cima** | `M5` | o servo empurra o pino do Pen Holder para cima |
| **Caneta embaixo** | `M3 S220` | o servo gira ~78° e a caneta desce por completo |

- **[decisão] `M5` = caneta em cima** por segurança: o GRBL executa `M5` ao ligar, resetar ou entrar em alarme, então qualquer pane levanta a caneta sozinha (como o freio de caminhão, que vem acionado por padrão).
- Depois de cada `M3` ou `M5`, o G-code leva **`G4 P0.3`** para o servo completar o curso antes de andar.
- **Altura:** com a caneta embaixo, a ponta apoia no papel com o Pen Holder 2–3 mm acima do batente. Com `M5`, a ponta sai do papel com pelo menos 3 mm de folga.
- **Pressão:** só com o peso do Pen Holder a esferográfica encostava mas **não riscava** **[medido]**. A mola resolveu.
- Rode **`gcode/testes/teste_caneta.gcode`**: cada tracinho deve começar e terminar nítido.

---

## 8. Rotina de uso

1. Ligar → conectar o LaserGRBL → **`$H`**.
2. Colocar o papel com o canto no (0,0) (use o gabarito da mesa).
3. Abrir o arquivo `.gcode` → play.
4. Entre desenhos **não precisa** refazer o `$H`: o G-code é absoluto (`G90`) e a máquina vai sozinha ao primeiro ponto com a caneta levantada.
5. Refaça o `$H` depois de: desligar, reconectar, reset, alarme ou empurrar a máquina com a mão.

**Dicas do LaserGRBL:**

- Não aceite a sugestão de ativar o **Laser Mode** (`$32=1`): o servo para de funcionar.
- Casinha = `$H`; raio = reset; cadeado = `$X`.
- Ao abrir a porta serial, o Uno reinicia: toda reconexão exige um novo `$H`.
- Depois de usar `G91`, volte para `G90`. Senão `G0 X0 Y0` vira "andar 0 mm" e parece que a máquina ignorou o comando.
- Comentários no G-code: use `;`. Parênteses aninhados como `( centro (60,60) )` dão erro *"Expected command letter"*.
- O LaserGRBL esconde a resposta do `?`. Para ver o estado dos pinos (`Pn:X`, `Pn:Y`), use o Monitor Serial da Arduino IDE, com o LaserGRBL desconectado (só um programa usa a porta por vez).

---

## 9. Qualidade do traço e velocidade

### 9.1 Micropasso faz toda a diferença

O primeiro desenho (quadrado + círculo) foi feito em **passo cheio**: as retas saíram boas, mas o círculo saiu tremido e com um barulho diferente no motor **[medido]**.

- Em passo cheio, cada passo anda 0,2 mm num tranco. Na curva, cada eixo acelera e freia o tempo todo e passa pela faixa em que o NEMA 17 entra em **ressonância** (~100–250 passos/s).
- Com **1/16**, cada passo anda 0,0125 mm. Passo cheio é descer uma escada de degraus altos; micropasso é descer uma rampa.

### 9.2 Testes em 1/16 (cartolina)

| Teste | Resultado **[medido]** |
|---|---|
| Retas de 400 mm (X) e 360 mm (Y), nos dois sentidos, F1500 | **perfeitas** |
| Círculos r = 40 mm em F500 e F1000 | **impecáveis** |
| Círculo em F2000 | pequenas ondulações, só bem de perto |
| Círculo em F4000 | um pouco mais de ondulação, ainda sutil |
| F2000 com 200 g no Apoio Secundário | ondulações quase imperceptíveis |
| F2000 com aceleração 400 | **não** melhorou |

**Conclusão:** não é folga (apareceria em qualquer velocidade) nem polia/driver (apareceria nas retas). As ondulações só aparecem com **curva + velocidade**: é um efeito **dinâmico** da elasticidade da correia e da massa da ponte. Analogia: carregar um copo cheio andando em círculo; devagar a água fica parada, rápido ela balança.

**Velocidade de trabalho [decisão]:** **F500** com velocidade fixa para precisão máxima (sem potência ou velocidade dinâmica). F1000–1500 ainda sai muito bom. Os deslocamentos com a caneta levantada (`G0`) continuam rápidos.

Para repetir o diagnóstico: **`gcode/testes/teste_velocidades.gcode`**.

---

## 10. Do desenho ao G-code

### 10.1 A cadeia

**Imagem ou SVG → (vetorização) → SVG de traço único → vpype → G-code → LaserGRBL → GRBL.**

### 10.2 SVG pronto → G-code

O script **`software/svg_para_gcode.py`** faz tudo de uma vez:

```
pip install vpype vpype-gcode
python svg_para_gcode.py desenho.svg --papel a4
python svg_para_gcode.py desenho.svg --papel 600x385 --margem 10 --rotacao -90
```

Ele junta traços que se encostam, tira sujeira (< 0,6 mm), **ordena os traços** para a caneta andar o mínimo possível levantada, encaixa o desenho no papel e gera o G-code com `M3 S220` / `M5`, `G4 P0.3` e **F500 em todas as linhas G1**. No pôster do F-16, a otimização reduziu o deslocamento com a caneta levantada de ~112 m para ~5 m.

### 10.3 Imagem → SVG (o ponto mais importante)

Para plotter, o desenho precisa ser de **traço único (centerline)**. O "Vetorizar bitmap" do Inkscape contorna as **bordas** de cada linha, e a caneta passaria duas vezes em cada traço. O processo que funcionou (exemplo completo em `software/exemplo-f16/`):

1. Normalizar o fundo da imagem e ampliar 4×.
2. Achar o **centro** de cada linha (filtro de crista + limiar com histerese). Isso separa linhas paralelas que estão quase coladas.
3. Preencher as "células" pequenas de sombreado, esqueletizar e podar os espinhos.
4. Suavizar e simplificar os traços.
5. Refazer textos com **fonte Hershey** (traço único). Acentos (Ç, Ã, É) não existem nessas fontes; desenhe-os como traços próprios.

Para fotos, o **DrawingBotV3** gera arte de linhas própria para plotter.

### 10.4 Usando o LaserGRBL para importar SVG

Se preferir importar o SVG direto no LaserGRBL:

- **Velocidade:** 500. **Modo:** `M3 - Constant Power`. **S-MIN:** 0 (caneta em cima). **S-MAX:** 220 (caneta embaixo).
- Ative o **suporte a PWM** nas configurações do LaserGRBL.
- Limitação: o LaserGRBL não insere pausa para o servo, então o começo de alguns traços pode falhar. Os arquivos gerados pelo `svg_para_gcode.py` já têm a pausa.

---

## 11. Solução de problemas

| Sintoma | Causa provável | Solução |
|---|---|---|
| LaserGRBL acusa *UnexpectedReset* logo depois do primeiro `M3` | servo ligado no 5 V do Arduino (brownout) | alimentar o servo pelo step-down |
| `G0 X0 Y0` "não faz nada" | Arduino resetou e perdeu a origem, ou ficou em `G91` | refazer `$H`; enviar `G90` |
| Servo não mexe | `$32=1` (laser) ou `$30=1000` | `$32=0` e `$30=255` |
| Servo gira ao contrário no meio do desenho | servo com defeito/ruído (aconteceu uma vez com o MG90S) | religar; se repetir, trocar o servo |
| Caneta encosta mas não risca | pouca pressão | mola no Pen Holder; conferir `S220` |
| Caneta raspa e trava no carro | folga zero entre caneta e carro (v2) | carro v3 com rasgo aberto de 16 mm |
| Ponte trepida de vez em quando | Apoio Secundário leve demais / sistema hiperestático | 1 só LM12UU na frente + peso de 150–200 g |
| Curvas onduladas | velocidade alta (efeito dinâmico) | F500–F1500 |
| Círculo tremido e barulho no motor | passo cheio (ressonância) | jumpers 1/16 e `$100=$101=80` |
| Carro bateu no fim do curso | perda de passos (aceleração alta) | aceleração ≤ 800 mm/s² |
| Motor dá "espasmos" sem andar | mau contato num fio do motor | refazer o conector (com tudo desligado) |
| Eixo anda ao contrário | plugue do motor invertido | `$3` ou girar o plugue |
| `ALARM:2` | destino fora da área (limite por software) | conferir o desenho e a origem; `$X` |
| Erro *"Expected command letter"* | parênteses aninhados no comentário | usar comentários com `;` |
| Alarme falso de fim de curso com motor andando | ruído no fio da chave | trançar sinal + GND, afastar dos motores, 100 nF perto do shield |
| UGS não conecta (botões desabilitados) | não identificada | usar o LaserGRBL, que conecta de primeira |

---

## 12. Lições das versões anteriores

Antes desta versão, a máquina passou por várias tentativas que deram errado. Elas explicam boa parte das decisões:

- **Trilhos MGN15H de 50 cm emendados:** o carro tremia e travava na junção. Trilho emendado com peça impressa nunca fica alinhado o bastante.
- **Barra de inox de 6 mm no apoio oposto do eixo longo:** os rolamentos "comiam" a barra, e ela envergava com o peso, exigindo contraflecha. As barras de 12 mm com LM12UU resolveram.
- **Ponte com 4 rolamentos:** hiperestática, trepidava. Ficou com 3 (2 que guiam + 1 que apoia).
- **Carro v1 → v2:** o servo não cabia (vão de 15,9 mm para um corpo de 22,5 mm), os furos dele eram grandes demais, o braço do servo batia no Pen Holder e o fim de curso quase não era acionado.
- **Carro v2 → v3:** a caneta raspava no "C" do carro. A v3 trouxe rasgo aberto, canal em V, guias duplas e mais rigidez.
- **Servo no 5 V do USB:** resets no meio do desenho. Fonte própria resolveu.

---

## 13. Arquivos deste pacote

| Pasta | Conteúdo |
|---|---|
| `esquemas/` | esquema de ligações interativo (HTML) |
| `modelos-3d/` | Base_CNC_Shield (STEP, STL e script); lista das demais peças |
| `firmware/` | configuração do GRBL, origem e comandos úteis |
| `gcode/testes/` | escala, caneta, quadrado + círculo e velocidades |
| `gcode/desenhos/` | logo do projeto e pôster do F-16 |
| `software/` | `svg_para_gcode.py`, logo, gerador de testes e o exemplo completo do F-16 |
| `dados/` | especificações em JSON (para usar no site) |
| `imagens/` | logo, prévias e simulações |
