# Mecânica

Nove peças impressas, desenhadas em volta do que eu já tinha: trilho MGN15H de 500 mm
com bloco, NEMA 17, encoder LPD3806, correia GT2 de 6 mm e só parafusos **M3 e M5**.

O projeto partiu de um pêndulo invertido visto no YouTube, mas quase nada foi copiado:
o encoder do vídeo era outro (maior, com outra furação), então o carro foi refeito do zero.

## Como foi modelado

- **CAD paramétrico em Python (CadQuery).** Cada peça é uma função; as medidas ficam no
  topo do arquivo (diâmetro da haste, dentes da polia, folgas dos furos). Trocar uma
  medida e rodar de novo regenera STL e STEP de tudo.
- **Tudo referenciado ao eixo do trilho.** A aba fina do suporte do motor e da base do
  esticador encosta na lateral do trilho: isso já põe a correia a 32 mm do eixo, alinhada
  com a garra do carro, sem medir nada na montagem.
- **Checagem de colisão automática.** Um script monta tudo com o carro no começo, no meio
  e no fim do trilho, e cruza peça com peça (volume da interseção > 0,5 mm³ = colisão).
  O cubo do pêndulo também é girado 360° contra o carro e as cabeças dos parafusos.
- **Imprimir sem suporte.** Furos horizontais em gota (ponta para cima), e cada peça já
  sai do script na orientação de impressão.

## Decisões e correções no caminho

| o que aconteceu | o que mudou |
|---|---|
| eu não tinha parafuso M4 | o tensor do esticador passou para M5 (furo de 5,3 mm e bolso para porca M5) |
| porca escondida embaixo de uma base parafusada na madeira não dá para apertar | esticador refeito: o carrinho desliza num rabo de andorinha a 45° e é puxado por um M5 com a porca por cima |
| a ponta da gota do furo do encoder cortava a parede até um dos rasgos | rasgos da flange girados 60°; parede inteira |
| medidas do encoder vinham de ficha, não do exemplar | **peça de teste** primeiro (só a flange e o começo do cubo, 51 min de impressão) antes do carro de ~4 h |
| o eixo do encoder real tinha 15 mm, não 13 | furo do cubo aprofundado para 15,6 mm |
| sem chave de fim de curso | o carro sempre parte encostado no batente do motor; o código conta a partir dali |

## Arquivos nesta pasta

| arquivo | o que é |
|---|---|
| `LEIA-ME_pecas_3D.md` | lista de peças, parafusos, medidas de montagem e ordem de montagem |
| `configuracao_impressao.md` | configuração do Cura para a Ender-3 V3 SE (PLA, 0,12 mm) |
| `stl_para_visualizar/` | as peças e a montagem completa em STL, para ver no navegador (o GitHub mostra STL em 3D) |

> Os STL desta pasta são para **visualizar**: estão na posição de montagem e com a malha
> do visualizador. Para **imprimir**, use os STL do pacote `pendulo_invertido.zip`
> (pasta `stl/`), que já vêm na orientação certa e com malha fina. O modelo paramétrico
> (`pendulo.py`, `check.py`, `export.py`) e os STEP editáveis também estão nesse pacote.
