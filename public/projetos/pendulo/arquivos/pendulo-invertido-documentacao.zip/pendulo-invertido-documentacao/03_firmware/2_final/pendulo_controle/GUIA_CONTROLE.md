# Guia do controle do pêndulo invertido

Código: `pendulo_controle.ino` (versão autônoma, sem comandos) · Arduino UNO · driver em 1/4 de passo · haste inox 500 mm / 110 g

---

## Como ligar

1. Ligue a outra ponta do **Y da fonte no P4 do Arduino**. Assim a fonte alimenta o Arduino e o motor juntos, e o computador não é mais necessário.
2. Com a fonte **desligada**: carro **encostado no batente do motor** e haste **pendurada e parada**.
3. Ligue a fonte.

Pronto. Depois de meio segundo o carro sai do batente já balançando a haste. Em uns **5 s** ela chega no topo e fica equilibrando.

**Para parar:** desligue a fonte.

**Para ligar de novo:** carro no batente do motor, haste pendurada e parada, e liga.

## O que ele faz

O código tem só dois modos, e troca entre eles sozinho:

| Modo | O que acontece |
|---|---|
| **Subida** | O carro faz um vai e vem e inverte o sentido bem quando a haste passa por baixo. É como empurrar um balanço: o empurrão rende mais na hora em que ele passa pelo ponto mais baixo. A cada passada a haste sobe mais. Perto da energia do topo, o vai e vem fica mais fraco, para ela chegar lá quase parada. |
| **Equilíbrio** | Quando a haste chega perto do topo (menos de 15°), indo para ele e com a energia certa, o equilíbrio assume. 200 vezes por segundo o carro corre para baixo da haste, como a mão equilibrando uma vassoura. |

**Ao ligar**, a saída do batente já é a subida: o carro vai para o meio da faixa e esse movimento já dá o primeiro empurrão na haste.

**Se o pêndulo cair** (passar de 30°), no mesmo ciclo de 5 ms ele volta para a subida. Não para, não espera e não volta ao centro antes. Como a haste ainda está balançando com a energia da queda, ela costuma voltar ao topo em uns **2 s**.

Na simulação (com o atrito medido, ruído, atraso de 5 ms e o modelo variando ±2 %):
- partindo do batente: ficou em pé em **60 de 60** testes, em 4,5 s típico e 10 s no pior caso;
- derrubando com tapas: reergueu em **38 de 38** quedas, em 1,9 s típico e 6 s no pior caso.

O carro nunca chegou a menos de 43 mm de nenhum batente.

## Segurança

- O gerador de passos **se recusa** a levar o carro a menos de **20 mm** de qualquer batente, mesmo que o controle peça.
- Faixa de trabalho de **±165 mm** a partir do centro, freando **antes** de chegar no fim.
- Perto do fim da faixa, a subida para de empurrar para fora e só puxa o carro de volta para o centro.
- **Conferência do 12 V:** ao ligar, o primeiro movimento é um empurrãozinho de 6 mm, só para o lado do centro. Se a haste não se mexer, o motor está sem força: o Arduino conclui que o carro continua no batente e tenta de novo a cada meio segundo, até a fonte ligar. Isso protege o caso "Arduino ligado no USB antes da fonte", que antes podia fazer o carro bater.

## USB e Monitor Serial (opcional)

- Não precisa do computador.
- Para ver o que está acontecendo, ligue o USB e abra o Monitor Serial (115200). Aparecem mensagens como `pegou` e `caiu 3`.
- ⚠️ **Abrir o Monitor Serial reinicia o Arduino.** Antes de abrir, coloque o carro no batente do motor com a haste pendurada e parada. O mesmo vale para enviar código novo.
- Plugar o USB com tudo já funcionando **não** reinicia. O que reinicia é abrir o Monitor Serial.

## Ajustes (topo do código)

| Ajuste | Para que serve |
|---|---|
| `CURSO_MM` (412) | espaço livre entre os batentes |
| `AJUSTE_CENTRO_MM` (+3) | empurra o centro: + vai para o esticador, − para o motor |
| `SW_VS` (0,35 m/s) | força do vai e vem da subida |
| `SW_EREF` (0,03) | alvo de energia da subida |
| `SW_KX` (2) | quanto a subida puxa o carro para o centro |

Se a subida precisar de ajuste no aparelho real:

| Sintoma | Ajuste |
|---|---|
| balança alto, mas para um pouco antes do topo e nunca pega | aumente `SW_EREF` (0,03 → 0,05) |
| chega no topo rápido demais, passa direto ou pega e cai logo | diminua `SW_EREF` (0,03 → 0,01) |
| demora muito para ganhar altura | aumente `SW_VS` (0,35 → 0,40) |
| o carro passa muito tempo nas pontas da faixa | aumente `SW_KX` (2 → 3) |

## Se algo der errado no equilíbrio

| Sintoma | Provável causa | O que fazer |
|---|---|---|
| tremedeira rápida, zumbido no motor | ganho de velocidade angular alto para o encoder | diminua `K_W` uns 20 % (−24,7 → −20) |
| equilibra, mas vai "passeando" devagar para um lado | zero do encoder levemente torto | normal no começo: o `K_BIAS` corrige em ~10 s. Se não corrigir, ligue de novo com a haste bem parada |
| motor apita e perde passo | aceleração alta demais para o motor | baixe `AMAX` de 8 para 6 |
| fica sempre no vai e vem, sem nunca subir | haste não estava parada ao ligar (zero errado) | desligue, espere a haste parar e ligue de novo |

## Números do pêndulo

- centro de massa a **215 mm** do eixo
- período de balanço pequeno, pendurado: **1,121 s** (medido e calculado batem)
- atrito seco do encoder: perde ~0,6° de amplitude por balanço
- `SINAL_ENCODER = 1` e `INVERTER_DIRECAO = false` já conferidos
