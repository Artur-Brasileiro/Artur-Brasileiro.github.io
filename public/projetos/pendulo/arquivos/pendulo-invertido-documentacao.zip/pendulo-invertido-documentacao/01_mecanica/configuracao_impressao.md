# Configuração de impressão

Impressora: Creality Ender-3 V3 SE · Fatiador: UltiMaker Cura · Material: PLA · Perfil base: **Super Quality (0,12 mm)**

O objetivo é deixar as peças **resistentes** e com **encaixes precisos** (trilho da capa, rolamentos, eixos).

## 1. Ajustes no Cura

| Seção | Ajuste | Valor | Por quê |
|---|---|---|---|
| Qualidade | Altura de Camada | **0,12 mm** | Dentes da polia e furos bem definidos. |
| Paredes | Número de Filetes da Parede | **4** | 1,6 mm de parede maciça: as peças finas ficam inteiras de plástico. |
| Paredes | Expansão Horizontal | **0,0 mm** | Os encaixes já foram desenhados com folga. Mexer aqui estraga as medidas. |
| Superior/Inferior | Espessura Superior | **1,0 mm** | Topo mais fechado e firme (8 camadas). |
| Superior/Inferior | Espessura Inferior | **0,84 mm** | 7 camadas. |
| Preenchimento | Densidade | **40 %** | Equilíbrio entre força e tempo (exceções abaixo). |
| Preenchimento | Padrão | **Giroide** | Forte em todas as direções. |
| Material | Temperatura de Impressão | **210 °C** | Camadas mais unidas, peça mais resistente. |
| Material | Temp. da Camada Inicial | **215 °C** | Primeira camada bem colada. |
| Material | Temperatura da Mesa | **60 a 65 °C** | Segura os cantos. |
| Velocidade | Velocidade de Impressão | **80 mm/s** | Parede mais bonita, medidas mais certas. |
| Percurso | Salto Z ao Retrair | **ligado** | O bico não arrasta na peça ao viajar. |
| Refrigeração | Ventoinha | **100 %** | PLA gosta de ventoinha cheia. |
| Suporte | Gerar Suporte | **DESLIGADO** | ⚠️ Todas as peças foram desenhadas para imprimir sem suporte. Com suporte, o Cura enche os furos e o encaixe não funciona. |
| Aderência | Tipo / Largura | **Brim, 5 mm** | Segura os cantos e sai fácil. |

Opcional: "Expansão Horizontal da Camada Inicial" em **−0,1 mm** tira o "pé de elefante".

## 2. Peças e ajustes especiais

Todas já vêm **na posição certa de imprimir**: é só abrir o STL e fatiar.

### Mecânica

| Arquivo | Qtd | Preenchimento | Observação |
|---|---|---|---|
| `carro_encoder` | 1 | 40 % | Peça principal do carro. |
| `garra_correia` | 1 | 40 % | Os dentinhos ficam para cima. |
| `cubo_pendulo` | 1 | **100 %** | Leva parafuso apertando no eixo do encoder e na haste. |
| `suporte_motor` | 1 | 40 % | |
| `polia_motor_gt2_30d` | 1 | **100 %** | Leva parafuso apertando no eixo do motor. |
| `esticador_base` | 1 | 40 % | |
| `esticador_carro` | 1 | 40 % | Desliza no rabo de andorinha da base; se ficar justo, lixe de leve o chanfro. |
| `rolo_esticador` | 1 | 40 % | Os 2 rolamentos 625ZZ entram por pressão. |
| `batente_trilho_x2` | **2** | 40 % | |

### Eletrônica

| Arquivo | Qtd | Preenchimento | Observação |
|---|---|---|---|
| `bandeja_eletronica` | 1 | 40 % | Maior peça (89 × 144 mm). O brim é importante aqui. |
| `capa_p4` | 1 | 40 % | Imprime em pé, do jeito que fica montada. |
| `pino_trava` | **2 ou 3** | **100 %** | Peça pequena e maciça; imprima uns a mais de reserva. |

## 3. Depois de imprimir: o que conferir

- [ ] **Capa do P4:** desliza pelo trilho da bandeja sem forçar.
- [ ] **Pino de trava:** entra justo, mas sem martelar.
- [ ] **Rolamentos no rolo do esticador:** entram com pressão firme.
- [ ] **Carrinho do esticador:** corre na base sem levantar.
- [ ] **Furos M3:** se algum sair apertado, broca de 2,5 mm (rosca) ou 3,2 mm (passagem) na mão.

## 4. Problemas comuns

| Problema | Solução |
|---|---|
| Cantos levantando | Mesa limpa com álcool isopropílico, mesa a 65 °C, brim de 5 mm, sem vento perto. |
| Fiapos (stringing) | Retração em 1,0 mm; se continuar, 205 °C. |
| Peça frágil, quebra nas camadas | 215 °C e 80 mm/s. |
| Dentes da polia ruins | Imprima só a polia a 40 mm/s. |
