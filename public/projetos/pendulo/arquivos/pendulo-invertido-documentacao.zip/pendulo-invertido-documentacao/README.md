# Pêndulo Invertido

Uma haste de inox de meio metro, em pé sobre um carrinho num trilho linear. Ao ligar a
fonte, o carro sai do batente balançando a haste até ela subir, e depois a segura em pé
corrigindo a posição 200 vezes por segundo. Se alguém dá um tapa e ela cai, ele sobe de
novo sozinho.

<!-- coloque aqui uma foto ou o vídeo do aparelho funcionando -->

| | |
|---|---|
| **Trilho** | MGN15H, 500 mm, 412 mm de curso livre |
| **Motor** | NEMA 17 (17HS4401S), driver A4988 em 1/4 de passo |
| **Transmissão** | correia GT2 6 mm, polia de 30 dentes impressa (0,075 mm por passo) |
| **Sensor** | encoder óptico LPD3806-1000BM, 4000 contagens por volta (0,09°) |
| **Haste** | inox Ø6 × 500 mm, 110 g, eixo a 35 mm da ponta |
| **Controle** | Arduino UNO, 200 Hz, subida por energia + equilíbrio LQR |
| **Peças** | 9 impressas em PLA, modeladas em CadQuery (Python) |

---

## Como ele funciona, sem fórmula

**Equilibrar** é o truque da vassoura na palma da mão: se ela tomba para a frente, você
anda com a mão para a frente, para ficar embaixo dela. O carro é a mão. A cada 5 ms o
Arduino olha quatro coisas (inclinação da haste, velocidade com que ela cai, onde o carro
está e a velocidade dele) e decide quanto acelerar o carro. O peso de cada uma das quatro
é calculado (método LQR): o maior é o da inclinação, e os pesos do carro o puxam de volta
para o meio devagar, para ele não chegar no fim do trilho.

**Subir** é empurrar um balanço: o empurrão rende mais quando o balanço passa pelo ponto
mais baixo. O carro faz um vai e vem e inverte o sentido bem nessa hora. A cada passada a
haste sobe mais. Perto da energia que ela precisa para chegar no topo, o vai e vem
enfraquece, para ela chegar lá quase parada, e aí o equilíbrio assume.

```
            encoder (4000/volta)          contagem de passos
                   │                              │
                   ▼                              ▼
        ┌─────────────────────── loop() a 200 Hz ───────────────────────┐
        │  ângulo θ, velocidade ω            posição x, velocidade v     │
        │                                                               │
        │  SUBINDO ──(perto do topo, indo para ele, energia certa)──►   │
        │     ▲                                            EQUILÍBRIO   │
        │     └────────────────(passou de 30°)─────────────────┘        │
        │                                                               │
        │  limites: 8 m/s² · 0,40 m/s · freia antes de ±165 mm           │
        └──────────────────────────────┬────────────────────────────────┘
                                       ▼ velocidade
                       gerador de passos (Timer1, interrupção)
                       trava: nunca a menos de 20 mm de um batente
                                       ▼
                               driver A4988 → NEMA 17
```

---

## Como foi construído

### 1. Mecânica (CAD paramétrico)

Tudo foi desenhado em volta do que eu já tinha, e com o que tinha na gaveta: só
parafusos M3 e M5. O modelo é um script Python (CadQuery): cada peça é uma função, as
medidas ficam no topo, e um segundo script monta o aparelho com o carro no começo, no meio
e no fim do trilho e acusa qualquer peça encostando em outra.

Antes de imprimir o carro (~4 h), imprimi uma **peça de teste** de 51 min: só a flange do
encoder e o começo do cubo. As medidas do encoder vinham de ficha técnica, e o eixo do
exemplar real era 2 mm mais comprido. Melhor descobrir isso numa peça pequena.

→ detalhes em [`01_mecanica/`](01_mecanica/)

### 2. Eletrônica

Protoboard, Arduino UNO e o driver de passo, tudo alimentado por uma fonte de 12 V com
um divisor Y. Encoder nos pinos D2 e D3 (os únicos do UNO com interrupção), driver em
D8, D9 e D10. Capacitor de 100 µF no 12 V do driver e corrente ajustada em 1,0 A
(Vref de 0,80 V) antes de ligar o motor.

→ [`02_eletronica/fiacao.html`](02_eletronica/fiacao.html) (diagrama interativo) e [`LIGACOES.md`](02_eletronica/LIGACOES.md)

### 3. Testes, um de cada vez

Antes do controle, cada parte foi testada sozinha, para que um defeito só tivesse um
suspeito:

| teste | resultado |
|---|---|
| encoder | 4000 contagens por volta, sem perder contagem em giro rápido |
| motor | sentido certo, 50 mm pedidos = 50 mm andados, 400 mm/s sem perder passo |
| partida | sem chave de fim de curso: o carro sempre começa encostado no batente do motor e o código conta a partir dali, nunca chegando a menos de 20 mm de um batente |

→ [`03_firmware/1_testes/`](03_firmware/1_testes/)

### 4. Medir a haste

O controle depende de como a haste balança. Pelo cronômetro, 10 idas e voltas deram
18 s, o que a física não explica para uma haste de 50 cm. Em vez de confiar no número,
o próprio encoder mediu: **1,121 s**, exatamente o valor calculado. O mesmo teste mostrou
o atrito do encoder: ~0,6° de amplitude perdidos por balanço.

→ [`05_medicoes/MEDICOES.md`](05_medicoes/MEDICOES.md)

### 5. Controle, primeiro no computador

Os ganhos do equilíbrio saíram de um LQR com as medidas da haste
([`calcular_ganhos.py`](04_controle_e_simulacao/calcular_ganhos.py) reproduz os valores
exatos do firmware). Depois, o mesmo código do Arduino rodou numa simulação com o encoder
de 4000 contagens, o motor de passo, o atrito medido, ruído e atraso:

| teste na simulação | resultado |
|---|---|
| partindo do batente do motor | em pé em **60 de 60**, em ~4,5 s |
| derrubando com tapas | reergueu em **38 de 38** quedas, em ~1,9 s |
| distância mínima de um batente | 43 mm |

→ [`04_controle_e_simulacao/`](04_controle_e_simulacao/)

### 6. Firmware final

Primeiro veio uma versão de bancada, com comandos pelo Monitor Serial (levantar a haste
com a mão e soltar quando o controle pegasse). Depois, a versão autônoma: liga a fonte e
ele confere o motor, sobe, equilibra e, se cair, volta a subir no mesmo ciclo de 5 ms.

→ [`03_firmware/2_final/pendulo_controle/`](03_firmware/2_final/pendulo_controle/)

---

## O que aprendi

- **Medir antes de calcular em cima.** O cronômetro deu 1,8 s; o encoder deu 1,121 s.
  Um ganho calculado com o número errado teria derrubado a haste e eu ia procurar o
  defeito no código.
- **Testar uma coisa de cada vez.** Encoder, motor, haste e só então o controle.
- **Peça de teste pequena antes da grande.** 51 minutos que salvaram uma impressão de 4 h.
- **Segurança no lugar mais baixo possível.** A trava dos 20 mm está dentro da
  interrupção que dá os passos, não no controle: nem um bug no controle passa dela.
- **Simular com os defeitos do mundo real.** Encoder em degraus, atraso, atrito e
  ±2 % no modelo. Uma simulação perfeita teria aprovado um controle frágil.

---

## Estrutura

```
01_mecanica/                 peças, parafusos, montagem, impressão e STL para visualizar
02_eletronica/               diagrama interativo (fiacao.html), ligações, energia e ajuste do driver
03_firmware/
  1_testes/                  teste_encoder, teste_motor, teste_motor_v2, medir_pendulo
  2_final/pendulo_controle/  o código que roda no aparelho + guia de uso
  3_historico/               a primeira versão do controle (bancada, com comandos)
04_controle_e_simulacao/     cálculo dos ganhos (LQR) e simulação do firmware
05_medicoes/                 período, atrito, curso e medidas das peças
```

Os sketches abrem direto no Arduino IDE (cada um numa pasta com o mesmo nome).
Os scripts Python precisam de `numpy` e `scipy`.
