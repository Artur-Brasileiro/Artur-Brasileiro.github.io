# Medições

Cada número da simulação e do controle veio do aparelho. Aqui está como foi medido.

## Período da haste: o cronômetro errou, o encoder acertou

Primeira tentativa: 10 idas e voltas no cronômetro deram **18 s**, ou 1,8 s por ciclo.
Pela física isso não fecha: nem uma haste de 50 cm com todo o peso na ponta passaria de
~1,16 s. Para dar 1,8 s ela teria de se comportar como uma de ~80 cm.

Em vez de recalcular tudo em cima de um número suspeito, o próprio encoder mediu
(sketch `03_firmware/1_testes/medir_pendulo`). A haste foi solta de ~30° e o Arduino
anotou o tempo de cada ida e volta:

```
ciclo 23: periodo 1.125 s | amplitude 17.1 graus
ciclo 24: periodo 1.124 s | amplitude 16.5 graus
ciclo 25: periodo 1.124 s | amplitude 15.8 graus
...
ciclo 46: periodo 1.117 s | amplitude 3.8 graus
ciclo 47: periodo 1.113 s | amplitude 3.2 graus
ciclo 48: periodo 1.112 s | amplitude 2.7 graus
------ RESUMO ------
periodo medio (amplitude < 20 graus): 1.121 s
idas e voltas ate a amplitude cair pela metade: 24
```

**1,121 s**, exatamente o valor calculado para a haste. O modelo estava certo; o erro foi
de contagem no olho, o que é muito comum.

## Atrito do encoder

Do mesmo teste: a amplitude cai ~0,6° por ida e volta, em linha reta (não em
exponencial). Isso é atrito **seco**, como uma borracha raspando, e não atrito de ar.
Foi esse número que entrou na simulação da subida, que é a parte que mais depende de atrito.

## Haste

| | |
|---|---|
| material | inox Ø6 mm |
| comprimento | 500 mm |
| massa | 110 g |
| eixo do encoder | a 35 mm de uma das pontas |
| centro de massa | 215 mm do eixo |

## Curso do carro

Com o carro no centro: 202 mm até um batente e 210 mm até o outro, ou **412 mm** de
batente a batente (`CURSO_MM`). O centro ficou 3 mm deslocado (`AJUSTE_CENTRO_MM = +3`).

## Encoder (paquímetro)

O modelo 3D começou com medidas de ficha técnica da série LPD3806. As do encoder real:

| | ficha | medido |
|---|---|---|
| corpo | Ø38 | Ø38 × 35 mm |
| ressalto | Ø20 × 5 | Ø20 × 5 mm |
| eixo além do ressalto | 13 mm | **15 mm** (55 no total) |

O eixo 2 mm maior fez o furo do cubo ser aprofundado (15,6 mm). Bloco MGN15H
(furos 25 × 25, corpo 32 × 59) e NEMA 17 (face 42 × 42, furos a 31) bateram com o modelo.

## Motor

- 1/4 de passo (MS2 no 5 V): 800 passos por volta.
- Polia GT2 de 30 dentes: 60 mm de correia por volta → **0,075 mm por passo** (13,33 passos/mm).
- Teste com régua: um comando de 50 mm andou 50 mm.
- 400 mm/s sem perder passo → `VMAX = 0,40 m/s`.
