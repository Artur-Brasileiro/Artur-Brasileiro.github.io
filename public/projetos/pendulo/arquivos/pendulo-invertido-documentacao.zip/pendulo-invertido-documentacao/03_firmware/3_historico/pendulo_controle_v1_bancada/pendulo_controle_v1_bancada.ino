/*
  PÊNDULO INVERTIDO - CONTROLE
  ============================
  Arduino UNO + A4988/DRV8825 (1/4 de passo) + NEMA 17 + polia GT2 30 dentes
  Encoder LPD3806-1000BM (4000 contagens/volta) + haste inox Ø6 x 500 mm (110 g)

  ANTES DE LIGAR A FONTE:
   1. Carro ENCOSTADO no batente do lado do MOTOR.
   2. Pêndulo PENDURADO e PARADO (o zero do ângulo é lido ao ligar).
  Ao ligar, espera 3 s e leva o carro devagar até o centro.

  COMANDOS (Monitor Serial, 115200):
   i = liga/desliga a leitura na tela (ângulo, posição, modo)
   b = EQUILÍBRIO: levante o pêndulo com a mão até em pé; quando passar perto
       do topo (menos de 3°, quase parado) o controle assume. Solte na hora.
   s = SUBIDA: o carro balança o pêndulo até o topo e equilibra sozinho
   x = PARA (freia, volta ao centro e espera)
   c = volta ao centro (só parado)

  PROTEÇÕES:
   - O carro nunca chega a menos de 20 mm de um batente (trava no próprio gerador de passos).
   - No equilíbrio, se o pêndulo passar de 30° ou o carro sair da faixa, ele freia e volta ao centro.
*/

// ====================== AJUSTES DE MONTAGEM ======================
const float CURSO_MM   = 410.0;   // de batente a batente (medido)
const float MARGEM_MM  = 20.0;    // distância mínima de cada batente (trava de segurança)
const bool  INVERTER_DIRECAO = false;  // já conferido: positivo = lado do esticador
const int   SINAL_ENCODER    = 1;     // CONFIRA com o comando 'i' (ver guia) e troque para -1 se precisar

// ====================== GANHOS (calculados para a sua haste) ======================
// Modelo: haste 500 mm, 110 g, pivô a 35 mm do topo -> centro de massa a 215 mm do pivô
const float K_X = -40.00;   // posição do carro (1/m)        -> a = -(K·estado)
const float K_V = -39.13;   // velocidade do carro
const float K_T = -179.9;   // ângulo (rad)
const float K_W = -24.66;   // velocidade angular (rad/s)
const float K_BIAS = -0.10; // corrige devagar um zero do encoder levemente torto

const float M_G_D   = 0.110 * 9.81 * 0.215;  // m·g·d (energia do pêndulo)
const float INERCIA = 0.007388;               // kg·m² em torno do pivô
// subida por energia (ver guia para ajustar)
const float SW_K    = 0.7;
const float SW_KX   = 2.0;
const float SW_KV   = 1.0;
const float SW_AMAX = 6.0;
const float SW_EREF = 0.05;

// ====================== LIMITES ======================
const float VMAX = 0.40;        // m/s  (testado: 400 mm/s sem perder passo)
const float AMAX = 8.0;         // m/s²
const float XLIM = 0.165;       // m, faixa de trabalho a partir do centro (±165 mm)
const float DT   = 0.005;       // s, controle a 200 Hz
const float ANG_PEGA   = 9.0  * PI / 180.0;   // a subida entrega para o equilíbrio abaixo disso
const float ANG_ARMA   = 3.0  * PI / 180.0;   // modo 'b': assume quando ficar quase em pé...
const float W_ARMA     = 0.5;                  // ...e quase parado (rad/s)
const float ANG_QUEDA  = 30.0 * PI / 180.0;   // desiste acima disso

// ====================== PINOS E MECÂNICA ======================
const uint8_t PIN_STEP = 9;     // PB1
const uint8_t PIN_DIR  = 8;     // PB0
const uint8_t PIN_EN   = 10;
const uint8_t ENC_A = 2, ENC_B = 3;
const float PASSOS_POR_MM = 800.0 / 60.0;
const long  CONT_VOLTA = 4000;
const float CENTRO_MM = CURSO_MM / 2.0;

// ====================== GERADOR DE PASSOS (Timer1) ======================
volatile long posPassos = 0;               // a partir do batente do motor
volatile bool andando = false;
volatile bool sentidoPos = true;
long posMinHard, posMaxHard;

ISR(TIMER1_COMPA_vect) {
  if (!andando) return;
  if (sentidoPos) { if (posPassos >= posMaxHard) return; posPassos++; }
  else            { if (posPassos <= posMinHard) return; posPassos--; }
  PORTB |= _BV(1);
  __builtin_avr_delay_cycles(40);          // ~2,5 µs de pulso
  PORTB &= ~_BV(1);
}

void velocidadeCarro(float v) {            // v em m/s (+ = lado do esticador)
  float pps = v * 1000.0 * PASSOS_POR_MM;
  bool pos = pps > 0;
  if (pps < 0) pps = -pps;
  if (pps < 31.0) { andando = false; return; }
  if (pps > 20000.0) pps = 20000.0;
  uint16_t topo = (uint16_t)(2000000.0 / pps) - 1;
  if (pos != sentidoPos) {
    andando = false;
    sentidoPos = pos;
    digitalWrite(PIN_DIR, (pos != INVERTER_DIRECAO) ? HIGH : LOW);
    delayMicroseconds(2);
  }
  noInterrupts();
  OCR1A = topo;
  if (TCNT1 > topo) TCNT1 = 0;
  andando = true;
  interrupts();
}

long lerPos() { noInterrupts(); long p = posPassos; interrupts(); return p; }
float xCentro() { return (lerPos() / PASSOS_POR_MM - CENTRO_MM) / 1000.0; }   // m, 0 = centro

// ====================== ENCODER ======================
volatile long contagem = 0;
volatile uint8_t encAnt = 0;
const int8_t TAB[16] = {0,-1,1,0, 1,0,0,-1, -1,0,0,1, 0,1,-1,0};
void isrEncoder() {
  uint8_t s = (PIND >> 2) & 0x03;
  contagem += TAB[(encAnt << 2) | s];
  encAnt = s;
}
float anguloPendurado() {                  // rad, 0 = pendurado
  noInterrupts(); long n = contagem; interrupts();
  return SINAL_ENCODER * n * (2.0 * PI / CONT_VOLTA);
}
float embrulha(float a) { while (a > PI) a -= 2*PI; while (a < -PI) a += 2*PI; return a; }

// ====================== ESTADO ======================
enum Modo { PARADO, ESPERA_TOPO, SUBINDO, EQUILIBRIO, FREANDO };
Modo modo = PARADO;
float vCmd = 0, bias = 0;
float histPhi[3] = {0, 0, 0};
bool telemetria = false;
unsigned long tProx = 0;
const char* nomeModo[] = {"parado", "espera topo", "subindo", "EQUILIBRIO", "freando"};

void moverPara(float alvoMM, float vel) {   // movimento lento com rampa, fora do controle
  const float acc = 0.5;                    // m/s²
  float v = 0;
  while (true) {
    float dist = (alvoMM - lerPos() / PASSOS_POR_MM) / 1000.0;
    if (fabs(dist) < 0.0002) break;
    float vAlvo = min(vel, sqrt(2 * acc * fabs(dist)));
    v = min(vAlvo, v + acc * 0.002);
    velocidadeCarro(dist > 0 ? v : -v);
    delay(2);
  }
  velocidadeCarro(0);
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_STEP, OUTPUT); pinMode(PIN_DIR, OUTPUT); pinMode(PIN_EN, OUTPUT);
  digitalWrite(PIN_EN, LOW);
  digitalWrite(PIN_DIR, INVERTER_DIRECAO ? LOW : HIGH);
  pinMode(ENC_A, INPUT_PULLUP); pinMode(ENC_B, INPUT_PULLUP);
  encAnt = (PIND >> 2) & 0x03;
  attachInterrupt(digitalPinToInterrupt(ENC_A), isrEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_B), isrEncoder, CHANGE);

  posPassos = 0;                                       // carro encostado no batente do motor
  posMinHard = lround(MARGEM_MM * PASSOS_POR_MM);
  posMaxHard = lround((CURSO_MM - MARGEM_MM) * PASSOS_POR_MM);

  TCCR1A = 0; TCCR1B = _BV(WGM12) | _BV(CS11);         // CTC, prescaler 8 -> 2 MHz
  OCR1A = 60000; TCNT1 = 0; TIMSK1 = _BV(OCIE1A);

  Serial.println(F("Pendulo invertido. Carro no batente do motor, pendulo pendurado e parado."));
  for (int s = 3; s > 0; s--) { Serial.print(F("Indo ao centro em ")); Serial.println(s); delay(1000); }
  noInterrupts(); contagem = 0; interrupts();          // zero do ângulo = pendurado parado
  moverPara(CENTRO_MM, 0.03);
  tProx = micros();
  Serial.println(F("Pronto. i = leitura | b = equilibrio (levante com a mao) | s = subida automatica | x = parar"));
}

void parar(const __FlashStringHelper* motivo) {
  if (modo != PARADO) { modo = FREANDO; Serial.print(F(">> ")); Serial.println(motivo); }
}

void loop() {
  // ---------- comandos ----------
  if (Serial.available()) {
    char c = Serial.read();
    if (c == 'i') telemetria = !telemetria;
    else if (c == 'x') parar(F("parado pelo usuario"));
    else if (c == 'b' && modo == PARADO) { modo = ESPERA_TOPO; Serial.println(F("Levante o pendulo devagar ate em pe...")); }
    else if (c == 's' && modo == PARADO) { modo = SUBINDO; vCmd = 0; Serial.println(F("Subindo...")); }
    else if (c == 'c' && modo == PARADO) { moverPara(CENTRO_MM, 0.05); tProx = micros(); }
  }

  // ---------- laço de controle a 200 Hz ----------
  if ((long)(micros() - tProx) < 0) return;
  tProx += (unsigned long)(DT * 1e6);

  float phi = anguloPendurado();
  histPhi[2] = histPhi[1]; histPhi[1] = histPhi[0]; histPhi[0] = phi;
  float w  = (histPhi[0] - histPhi[2]) / (2 * DT);       // rad/s
  float th = embrulha(phi - PI);                        // rad, 0 = em pé, + = topo para o lado do esticador
  float x  = xCentro();
  float a  = 0;

  switch (modo) {
    case PARADO:
      vCmd = 0; break;

    case ESPERA_TOPO:
      vCmd = 0;
      if (fabs(th) < ANG_ARMA && fabs(w) < W_ARMA) { modo = EQUILIBRIO; bias = 0; Serial.println(F(">> equilibrando! pode soltar")); }
      break;

    case SUBINDO: {
      if (fabs(th) < ANG_PEGA && fabs(w) < 4.0) { modo = EQUILIBRIO; bias = 0; Serial.println(F(">> pegou no topo!")); }
      else {
        float E = (0.5 * INERCIA * w * w + M_G_D * (cos(th) - 1)) / (2 * M_G_D);   // 0 = topo, -1 = pendurado
        float p = w * cos(th);
        float sg = (p >= 0) ? 1.0 : -1.0;
        float e = SW_K * (SW_EREF - E) * 9.81;
        if (e >  SW_AMAX) e =  SW_AMAX;
        if (e < -SW_AMAX) e = -SW_AMAX;
        a = -e * sg - SW_KX * x - SW_KV * vCmd;
      }
      if (modo != EQUILIBRIO) break;
    }  // se acabou de pegar, já calcula o equilíbrio neste mesmo ciclo
    // fallthrough
    case EQUILIBRIO:
      if (fabs(th) > ANG_QUEDA)     { parar(F("o pendulo caiu")); break; }
      if (fabs(x) > XLIM + 0.01)    { parar(F("carro saiu da faixa")); break; }
      bias += K_BIAS * x * DT;
      a = -(K_X * x + K_V * vCmd + K_T * (th - bias) + K_W * w);
      break;

    case FREANDO:
      if (fabs(vCmd) <= AMAX * DT) {
        vCmd = 0; velocidadeCarro(0); modo = PARADO;
        delay(300);
        moverPara(CENTRO_MM, 0.05);
        Serial.println(F("Parado no centro. b = equilibrio | s = subida"));
        tProx = micros();
        return;
      }
      a = (vCmd > 0) ? -AMAX : AMAX;
      break;
  }

  if (modo == SUBINDO || modo == EQUILIBRIO || modo == FREANDO) {
    if (a >  AMAX) a =  AMAX;
    if (a < -AMAX) a = -AMAX;
    vCmd += a * DT;
    float vPos = sqrt(max(0.0f, 2 * AMAX * (XLIM - x)));    // freia antes do limite
    float vNeg = sqrt(max(0.0f, 2 * AMAX * (XLIM + x)));
    if (vCmd >  min(VMAX, vPos)) vCmd =  min(VMAX, vPos);
    if (vCmd < -min(VMAX, vNeg)) vCmd = -min(VMAX, vNeg);
    velocidadeCarro(vCmd);
  } else {
    velocidadeCarro(0);
  }

  // ---------- leitura na tela (10 Hz) ----------
  static uint8_t div = 0;
  if (telemetria && ++div >= 20) {
    div = 0;
    Serial.print(F("ang(0=em pe): ")); Serial.print(th * 180.0 / PI, 1);
    Serial.print(F("  x: ")); Serial.print(x * 1000.0, 0);
    Serial.print(F(" mm  modo: ")); Serial.println(nomeModo[modo]);
  }
}
